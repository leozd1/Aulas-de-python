# Resposta do Exercicio 115a
# criando funções 
def linha(tam = 42): # vai fazer um linha, caso não seja definido o parametro, ele sera de 42 carateres
    return '\033[1m=\033[m' * tam


def cabeçalho (txt, cor = '\033[m'): # cria o cabeçalho com um texto como parametro, usando a linha(), Pra decorar 
    if cor == 'vermelho': # e esquema de cores nas opções de mensagens
        txt = f'\033[01;31m{txt}\033[m'
    elif cor == 'amarelo':
        txt = f'\033[01;33m{txt}\033[m'
    elif cor == 'verde':
        txt = f'\033[01;32m{txt}\033['
    elif cor == 'branco':
        txt = f'\033[04;37m{txt}\033[m'
    elif cor == 'cinza':
        txt = f'\033[7;37m {txt} \033[m'
    else:
        txt = txt
                    
    print(linha())
    print(txt.center(50))
    print(linha())
   
   
def menu(lista): # organiza a lista em um menu simples com retorno da opçção
    cabeçalho('MENU PRINCIPAL', 'cinza')
    c = 1
    for item in lista:
        print(f'\033[0;33m{c}\033[m - \033[1;36m{item}\033[m')
        c+=1
    print(linha())
    opc = leiaInt('\033[1;32mSua opção: \033[m') 
    return opc

    
def leiaInt(num): # ler a opção de forma de inteiro
    while True:
        try:
            entrada = int(input(num))            
        except (TypeError, ValueError):
            print(f'\033[1;31m ERRO: Digite um valor inteiro\033[m') 
            continue # apos o teste ele joga no laço novamente para testar    
        except (KeyboardInterrupt): # caso queria interronper com (ctrl + c), que ele retorna um 0
            print('Entrada de dados interrompida pelo usuario')
            return 0    
        else:
            return entrada    
