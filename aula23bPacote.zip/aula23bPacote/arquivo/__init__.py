# resposta do exercicio 115b
# criação de arquivo
from aula23bPacote.interface import cabeçalho

def arquivoExiste(nome): # função pra verificar a existência do arquivo
    try:
        a = open(nome, 'rt') # open para abrir o arquivo, "rt": (r) read, pra ler o  texto (t) text
        a.close() # fecha logo 
    except FileNotFoundError: # O arquivo não foi encontrado
        return False
    else: # Senão ele existe
        return True
    
    
def criarArquivo(nome):
    try: # testa se o arquivo não existe 
        a = open(nome, 'wt+', encoding='utf-8') # abe o arquivo, wt+: (w), escreve o texto, ou arquivo (t), o (+), cria o arquivo
        a.close() # fecha o arquivo quando o cria, e o encoding='utf-8' para evitar erros com acentos    
    except:
        print('houve erro na criação do arquivo! Mals ai')        
    else:
        print(f'Arquivo {nome} criado com sucesso!')
        
        
def lerArquivo(nome):
    try:
        a = open(nome, 'rt') # para ler o arquivo somente, não precisa dar close()  
    except:
        print('Erro ao lar o arquivo!') 
    else:
        cabeçalho('PESSOAS CADASTRADAS')
        for linha in a:
            dado = linha.split(';')
            dado[1] = dado[1].replace('\n', '')
            print(f'{dado[0]:<10} {dado[1]:>10} anos')
            
        '''b = a.readlines()
        for n, v in enumerate(b):
            print(f'{n} - {v}')'''
    finally:
        a.close()
            
# Exercicio extra do 115b
def excluirArquivo(nome):
    try:
        b = []
        a = open(nome, 'rt')
        b = a.readlines()   
        b.remove(a.read())
        a.close()
        
    except:
        print('Erro, dado não removido, verifica ae!')
    else: 
        print(f'{b} removido com sucesso!')
        for n, v in enumerate(b):
            print(f'\033[0;35m{n}\033[m - {v}')

# readlines: parece ler o conteudo do arquivo como uma lista, com a quebra de linha (\n) para casos de pulo de linha
# realine: parece que lê somente a primeira linha somente
# read: ler o conteudo completo, sem formatação nenhuma             
            
# Resposta do Exercicio 115c
def cadastrar(arq, nome = 'desconhecido', idade = 0): # cadastro com paramentros de nome e idade definidos caso não tenham
    try: # vai tentar abrir o arquivo, por isso o try, pra tentar ou testar o arquivo
        a = open(arq, 'at') # o 'at', a de adicionar(appenend) itens ao texto (text) do arquivo
    except:
        cabeçalho('Houve um erro na abertura do arquivo')
    else:
        try:
            a.write(f'{nome}; {idade}\n') # .write serve para escrever dentro do arquivo
        except:
            print('Houve erro no hora de escrever os dados!')
        else:
            print(f'Novo registro de {nome} feito com sucesso!')
            a.close()
        