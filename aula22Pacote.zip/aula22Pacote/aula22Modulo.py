def fatorial(n): # onde o paramentro de entrada é o numero recebido
    f = 1 # sendo o fatorial iniciado por 1, pos ele é um fator de multiplicação, ja que 0 é multilpador de zero
    for c in range(1, n+1): # e o for conta de 1 ate o numero somado com mais 1
        f*=c # onde o contador recebe o numero e multiplica por ele mesmo.
    return f # e o retorno sera o fatorial do numero 

# só pra aumentar o tamanho do codigo
def dobro(n):
    return n * 2

def triplo(n):
    return n * 3