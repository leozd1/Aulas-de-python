# Resposta do exercicio 112
def escreva (msn): # o paramentro sera a mensagem chamada
    valido = False # para julgar se o dado informado  é valido ou não
    while not valido:
        entrada = str(input(msn)).replace(',', '.').strip() # a entrada de valores é testada, 
                                                            # replace(),onde tiver virgula, substitui por ponto, ja que é o separador
                                                            # strip(), fatia a palavra(ou numero), e remove os espaços vazios
        if entrada.isalpha() or entrada == '': # se for alfanumerico ou tiver algum vazio, apresenta a mensagem
            print(f'\033[1;31m ERRO: \"{entrada}\" é valor invalido!\033[m') 
        else:
            valido = True
            return float(entrada)
        
