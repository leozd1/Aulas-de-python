# Resposta do exercicio 111
def aumentar(preco = 0, taxa = 0, formato = False):
    res = preco + (preco * taxa /100)
    return res if formato is False else moeda(res) # só retorne como res, se formato for Falso, senão retorne moeda(res)
                                                    # moeda(res) = formatado bonitinho, como na função moeda
  
def diminuir(preco = 0, taxa =0, formato = False): 
    res = preco - (preco * taxa / 100) 
    return res if not formato else moeda(res) # a mesma coisa, so muda a forma da escrita
                                              # só retorne res se não for o formato, senão retorne moeda(res)

def dobro(preco =0, formato = False ):
    res = preco * 2
    return res if not formato else moeda(res)
    
def metade(preco=0, formato = False):
    res = preco / 2
    return res if formato is False else moeda(res)

def moeda(preco=0, moeda='R$ '): 
    return f'{moeda}{preco:>.2f}'.replace('.',',')

def resumo(preco=0, taxaaum=10, taxared=5):
    print('\033[0;33m==\033[m'*30)
    print('RESUMO DOS VALORES'.center(60)) # centralizado em 30 caracteres
    print('\033[0;34m==\033[m'*30)
    print(f'Preço analisado: \t{moeda(preco)}')
    print(f'Dobro do preço: \t{dobro(preco, True)}') # mostra o dobro do valor, formatado(True), por que é bonitinho
    print(f'Metade do preço: \t{metade(preco, True)}') # \t , mostra com formatação tabulada (tabela)
    print(f'Com {taxaaum}%  de aumento: \t{aumentar(preco, taxaaum, True)}')
    print(f'Com {taxared}% de desconto: \t{diminuir(preco, taxared, True)}')
    print('\033[0;35m~~\033[m'*30)