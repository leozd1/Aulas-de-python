# Modulos do exercicio 107 do arquivo aula22b.py
'''
def aumentar(preco = 0, taxa = 0):
    res = preco + (preco * taxa /100)
    return res
  
  
def diminuir(preco = 0, taxa =0): # preco e taxa de uma função, nao é a mesma de outra
    res = preco - (preco * taxa / 100) # já que são variaveis locais, só o nome é igual
    return res


def dobro(preco =0 ):
    res = preco * 2
    return res
    
    
def metade(preco=0):
    resp = preco / 2
    return resp  

'''  

# Resposta do exercicio 108
'''
def moeda(preco=0, moeda='R$'): # É acrescendido o zero para tornar-lo opcional, caso não seja dado nenhum valor
                                # e moeda é dado o cifrão para torna-lo valor de real
    return f'{moeda}{preco:>.2f}'.replace('.',',') # teria 8 casa, com 2 decimais, alinhado a direita
'''
# Exercico 109
def aumentar(preco = 0, taxa = 0, formato = False):
    res = preco + (preco * taxa /100)
    return res if formato is False else moeda(res) # só retorne como res, se formato for Falso, senão retorne moeda(res)
                                                    # moeda(res) = formatado bonitinho, como na função moeda
  
def diminuir(preco = 0, taxa =0, formato = False): 
    res = preco - (preco * taxa / 100) 
    return res if not formato else moeda(res) # a mesma coisa, so muda a forma da escrita
                                              # só retorne res se não for o formato, senão retorne moeda(res)

def dobro(preco =0, formato = False ):
    res = preco * 2
    return res if not formato else moeda(res)
    
def metade(preco=0, formato = False):
    resp = preco / 2
    return resp if formato is False else moeda(resp)

def moeda(preco=0, moeda='R$'): 
    return f'{moeda}{preco:>.2f}'.replace('.',',') # teria 8 casa, com 2 decimais, alinhado a direita
